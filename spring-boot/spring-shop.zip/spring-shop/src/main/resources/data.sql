INSERT INTO jewelry (name, color, price, price_new, image) VALUES ('French Pave Diamond Engagement Ring in Platinum (1/4 ct. tw.)', 'Platinum', 175000,131250, FILE_READ('classpath:static/im-1.png'));
INSERT INTO jewelry (name, color, price, price_new, image) VALUES ('Petite Solitaire Engagement Ring in Platinum', 'White', 89000,66750, FILE_READ('classpath:static/im-2.png'));
