package org.itstep.springrestopenserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestOpenserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringRestOpenserverApplication.class, args);
    }

}
