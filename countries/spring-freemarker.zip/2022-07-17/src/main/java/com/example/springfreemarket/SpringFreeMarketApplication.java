package com.example.springfreemarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFreeMarketApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringFreeMarketApplication.class, args);
    }

}
