package com.example.springfreemarket.views;

import lombok.Data;

@Data
public class StateCountry {
    private Long id;
    private String name;
    private String countryName;
}
